#ifndef INCLUDE_FILEWRITERCLASS_CPP_H
#define INCLUDE_FILEWRITERCLASS_CPP_H
#include <vector>
#include <string>
using namespace std;


int local_mbr_to_file(vector <long double>, std::string);

#endif
