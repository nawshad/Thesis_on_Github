#ifndef INCLUDE_GLOBALMBR_CPP_H
#define INCLUDE_GLOBALMBR_CPP_H
#include <vector>
#include <string>
using namespace std;

vector <long double> encomp_mbr_calc(vector <long double>);
int local_mbr_calc(std::string);

#endif
