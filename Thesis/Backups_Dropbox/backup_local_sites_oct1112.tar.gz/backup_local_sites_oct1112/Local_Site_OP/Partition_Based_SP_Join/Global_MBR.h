#ifndef INCLUDE_GLOBALMBR_CPP_H
#define INCLUDE_GLOBALMBR_CPP_H
#include <vector>
#include <string>
using namespace std;

vector <long double> encomp_mbr_calc(vector <long double>,int );
int global_mbr_calc();

#endif
